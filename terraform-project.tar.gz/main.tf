terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "3.105.0"
    }
  }
}

resource "azurerm_resource_group" "mate-terraform" {
  name     = var.resource_group_name
  location = var.location
}

resource "azurerm_storage_account" "mate-terraform-storage" {
  name                     = var.storage_account_name
  resource_group_name      = azurerm_resource_group.mate-terraform.name
  location                 = azurerm_resource_group.mate-terraform.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
}

resource "azurerm_storage_container" "mate-terraform-vhds" {
  name                  = var.container_name
  storage_account_id    = azurerm_storage_account.mate-terraform-storage.id
  container_access_type = "private"
}

resource "azurerm_storage_blob" "mate-terraform-blob" {
  name                   = var.blob_name
  storage_account_name   = azurerm_storage_account.mate-terraform-storage.name
  storage_container_name = azurerm_storage_container.mate-terraform-vhds.name
  type                   = "Block"
  source                 = "some-local-file.zip"
}

Compress-Archive -Path "C:\Users\Asus\OneDrive - kpi.ua\Рабочий стол\Terraform\terraform_task_2_working_with_terraform\*" -DestinationPath "C:\Users\Asus\OneDrive - kpi.ua\Рабочий стол\Terraform\terraform_task_2_working_with_terraform\terraform-project.zip"